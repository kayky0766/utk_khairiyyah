<div class="mt-4">  
  <h2 class="mb-4">Kelola Carousel</h2>
  <a href="?page=addcarousel" class="btn btn-primary mb-3">
    <i class="fas fa-plus"></i> Tambah Carousel
  </a>

  <!-- Table -->
  <div class="table-responsive">
    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>No</th>
          <th>Gambar</th>
          <th>Judul</th>
          <th>Deskripsi</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include '../lib/conn.php';
        $no = 1;
        $sqlOut = $conn->query("SELECT * FROM tb_carousel");
        while ($row = $sqlOut->fetch_assoc()) {
          $id = (int)$row['id'];
          $image = !empty($row['image_url']) ? $row['image_url'] : 'default.png';
          $title = !empty($row['title']) ? htmlspecialchars($row['title']) : '<em>Tidak ada judul</em>';
          $description = !empty($row['description']) ? htmlspecialchars($row['description']) : '<em>Tidak ada deskripsi</em>';
          ?>
          <tr>
            <td><?php echo $no++; ?></td>
            <td>
              <img src="../gbrproduk/<?php echo $image; ?>" alt="Gambar" style="width: 100px; height: auto;">
            </td>
            <td><?php echo $title; ?></td>
            <td><?php echo $description; ?></td>
            <td>
              <a href="?page=editcarousel&id=<?php echo $id; ?>" class="btn btn-warning btn-sm">
                <i class="fas fa-edit"></i>
              </a>
              <a href="?page=deletecarousel&id=<?php echo $id; ?>" 
                 onclick="return confirm('Yakin ingin menghapus?')" 
                 class="btn btn-danger btn-sm">
                <i class="fas fa-trash"></i>
              </a>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
