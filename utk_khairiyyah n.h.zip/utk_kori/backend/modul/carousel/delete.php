<?php
include('../../../lib/conn.php');

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    
    $cek = mysqli_query($conn, "SELECT * FROM tb_carousel WHERE id = '$id'");
    
    if (mysqli_num_rows($cek) > 0) {
        $data = mysqli_fetch_assoc($cek);
        $gambar = $data['image_url'];

        $gambarPath = "../../gbrproject/" . $gambar;
        if (file_exists($gambarPath) && is_file($gambarPath)) {
            unlink($gambarPath);
        }

        $delete = mysqli_query($conn, "DELETE FROM tb_carousel WHERE id = '$id'");

        if ($delete) {
            header("Location: dashboard.php?page=carousel");
            exit;
        } else {
            echo "Gagal menghapus data: " . mysqli_error($conn);
        }
    } else {
        echo "Data tidak ditemukan.";
    }
} else {
    echo "ID tidak disediakan.";
}
?>
