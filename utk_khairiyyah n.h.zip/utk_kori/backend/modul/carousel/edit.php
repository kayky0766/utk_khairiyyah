<?php
include '../lib/conn.php';

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_carousel WHERE id='$id'"));

if (isset($_POST['btn'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    $image_url = $data['image_url']; 

    if (!empty($_FILES['gambar']['name'])) {
        $targetDir = "../../gbrproject/";
        $newImage = basename($_FILES["gambar"]["name"]);
        $targetFile = $targetDir . $newImage;

        $oldImagePath = $targetDir . $image_url;
        if (file_exists($oldImagePath) && is_file($oldImagePath)) {
            unlink($oldImagePath);
        }

        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFile)) {
            $image_url = $newImage;
        } else {
            echo "Gagal upload gambar.";
            exit;
        }
    }

    $query = "UPDATE tb_carousel 
              SET title='$title', description='$description', image_url='$image_url' 
              WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php?page=carousel");
        exit;
    } else {
        echo "Gagal update data: " . mysqli_error($conn);
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label>Judul:</label>
    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($data['title']) ?>" required>

    <label>Deskripsi:</label>
    <textarea name="description" class="form-control" rows="4" required><?= htmlspecialchars($data['description']) ?></textarea>

    <label>Gambar saat ini:</label><br>
    <img src="../../gbrproject/<?= $data['image_url'] ?>" alt="Gambar Sekarang" style="width: 150px;"><br><br>

    <label>Ganti Gambar (opsional):</label>
    <input type="file" name="gambar" class="form-control">

    <button type="submit" name="btn" class="btn btn-success mt-3">Update</button>
</form>
