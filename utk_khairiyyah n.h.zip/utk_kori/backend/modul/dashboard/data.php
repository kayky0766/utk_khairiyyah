<style>
    .btn-primary{
        background-color: #014a57;
    }
</style>
<div class="d-flex justify-content-center gap-2 mt-3">
    <h3>Selamat Datang User</h3> 
</div>

<div class="d-flex justify-content-center gap-2 mt-3">
<a href="?page=carousel" class="btn btn-primary">Carousel</a>
</div>