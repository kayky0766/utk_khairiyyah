<?php
include '../lib/conn.php';

if (isset($_POST['btn'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

   $image_url = '';
if (!empty($_FILES['gambar']['name'])) {
    $image_url = basename($_FILES["gambar"]["name"]); 

    
    $targetDir = "../gbrproduk/";
    $targetFile = $targetDir . $image_url;
    if (!file_exists("../gbrproduk")) {
    mkdir("../gbrproduk", 0777, true);
}

if (is_uploaded_file($_FILES['gambar']['tmp_name'])) {
    echo "File siap dipindahkan<br>";
} else {
    echo "File tidak tersedia untuk dipindahkan<br>";
}

    
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $mimeType = mime_content_type($_FILES['gambar']['tmp_name']);

    if ($fileType === 'png' && $mimeType === 'image/png') {
        if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFile)) {
            // Sukses upload
        } else {
            echo "Gagal upload gambar.";
            exit;
        }
    } else {
        echo "Hanya gambar PNG yang diperbolehkan.";
        exit;
    }
}


    $query = "INSERT INTO tb_carousel (image_url, title, description) 
              VALUES ('$image_url', '$title', '$description')";

    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php?page=carousel");
    } else {
        echo "Gagal input data: " . mysqli_error($conn);
    }
}
?>

<form action="" method="POST" enctype="multipart/form-data">
    <label>Judul:</label>
    <input type="text" name="title" class="form-control" required>

    <label>Deskripsi:</label>
    <textarea name="description" class="form-control" rows="4" required></textarea>

    <label>Gambar:</label>
    <input type="file" name="gambar" class="form-control" required>

    <button type="submit" name="btn" class="btn btn-success mt-2">Simpan</button>
</form>
