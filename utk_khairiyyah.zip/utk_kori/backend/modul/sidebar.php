<div class="sidebar">
    <h4>america food</h4>
    <a href="?page=dashboard"><i class="fas fa-home"></i> Dashboard</a>
    <a href="?page=carousel"><i class="fas fa-images"></i> Carousel</a>
    <a href="?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>