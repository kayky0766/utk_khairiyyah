<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Protected Website</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6B73FF 0%, #000DFF 100%);
            min-height: 100vh;
        }
        
        /* Auth Styles */
        .auth-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 350px;
            padding: 30px;
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        /* Website Styles */
        .website-container {
            display: none;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            color: #333;
        }
        
        header {
            background-color: white;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-weight: 600;
            font-size: 20px;
            color: #6B73FF;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            background-color: #6B73FF;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 500;
        }
        
        .logout-btn {
            padding: 8px 15px;
            background: #6B73FF;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }
        
        .main-content {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 30px;
        }
        
        .feature-card {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        /* Shared Styles */
        .auth-title {
            color: #333;
            margin-bottom: 25px;
            font-size: 24px;
            font-weight: 600;
        }
        
        .input-field {
            margin-bottom: 20px;
            position: relative;
        }
        
        .input-field input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: all 0.3s;
        }
        
        .input-field input:focus {
            border-color: #6B73FF;
        }
        
        .auth-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(to right, #6B73FF, #000DFF);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
        }
        
        .auth-btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        
        .switch-auth {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .switch-auth a {
            color: #6B73FF;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
        }
        
        .error-message {
            color: red;
            font-size: 13px;
            margin-top: 5px;
            text-align: left;
            display: none;
        }
    </style>
</head>
<body>
    <!-- Auth Container (Login/Register) -->
    <div class="auth-container" id="authContainer">
        <!-- Login Form -->
        <div id="loginForm">
            <h1 class="auth-title">Masuk ke Akun Anda</h1>
            
            <form id="loginFormElement">
                <div class="input-field">
                    <input type="text" id="loginEmail" placeholder="Email" required>
                    <div class="error-message" id="loginEmailError"></div>
                </div>
                
                <div class="input-field">
                    <input type="password" id="loginPassword" placeholder="Password" required>
                    <div class="error-message" id="loginPasswordError"></div>
                </div>
                
                <button type="submit" class="auth-btn">MASUK</button>
            </form>
            
            <div class="switch-auth">
                Belum punya akun? <a id="showRegister">Daftar disini</a>
            </div>
        </div>
        
        <!-- Register Form (Hidden by default) -->
        <div id="registerForm" style="display: none;">
            <h1 class="auth-title">Buat Akun Baru</h1>
            
            <form id="registerFormElement">
                <div class="input-field">
                    <input type="text" id="registerName" placeholder="Nama Lengkap" required>
                    <div class="error-message" id="registerNameError"></div>
                </div>
                
                <div class="input-field">
                    <input type="email" id="registerEmail" placeholder="Email" required>
                    <div class="error-message" id="registerEmailError"></div>
                </div>
                
                <div class="input-field">
                    <input type="password" id="registerPassword" placeholder="Password" required>
                    <div class="error-message" id="registerPasswordError"></div>
                </div>
                
                <div class="input-field">
                    <input type="password" id="registerConfirmPassword" placeholder="Konfirmasi Password" required>
                    <div class="error-message" id="registerConfirmPasswordError"></div>
                </div>
                
                <button type="submit" class="auth-btn">DAFTAR</button>
            </form>
            
            <div class="switch-auth">
                Sudah punya akun? <a id="showLogin">Masuk disini</a>
            </div>
        </div>
    </div>
    
    <!-- Website Content (Hidden until logged in) -->
    <div class="website-container" id="websiteContainer">
        <header>
            <div class="logo">MyWebsite</div>
            <div class="user-menu">
                <div class="user-avatar" id="userAvatar">JD</div>
                <button class="logout-btn" id="logoutBtn">Keluar</button>
            </div>
        </header>
        
        <div class="main-content">
            <h1>Selamat Datang di Website Kami</h1>
            <p>Anda sekarang dapat mengakses semua fitur eksklusif kami.</p>
            
            <div class="features">
                <div class="feature-card">
                    <h3>Sepatu Adidas</h3>
                    <img src="aset/img/s1.png" alt="shoes">
                </div>
                <div class="feature-card">
                    <h3>Sepatu Nike</h3>
                    <img src="aset/img/s3.png" alt="shoes">
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Simpan data user (dalam implementasi real, ini akan disimpan di database)
        let users = [
            { id: '1', name: 'floraaulia', email: 'floraaulia123@gmail.com', password: 'generasi123' }
        ];
        let currentUser = null;
        
        // DOM Elements
        const authContainer = document.getElementById('authContainer');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        const websiteContainer = document.getElementById('websiteContainer');
        const showRegister = document.getElementById('showRegister');
        const showLogin = document.getElementById('showLogin');
        const logoutBtn = document.getElementById('logoutBtn');
        const userAvatar = document.getElementById('userAvatar');
        
        // Toggle between Login and Register forms
        showRegister.addEventListener('click', () => {
            loginForm.style.display = 'none';
            registerForm.style.display = 'block';
        });
        
        showLogin.addEventListener('click', () => {
            registerForm.style.display = 'none';
            loginForm.style.display = 'block';
        });
        
        // Handle Register
        document.getElementById('registerFormElement').addEventListener('submit', function(e) {
            e.preventDefault();
            resetErrorMessages('register');
            
            const name = document.getElementById('registerName').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('registerConfirmPassword').value;
            
            let isValid = true;
            
            if (name.length < 3) {
                showError('registerNameError', 'Nama minimal 3 karakter');
                isValid = false;
            }
            
            if (!validateEmail(email)) {
                showError('registerEmailError', 'Email tidak valid');
                isValid = false;
            } else if (users.some(user => user.email === email)) {
                showError('registerEmailError', 'Email sudah terdaftar');
                isValid = false;
            }
            
            if (password.length < 6) {
                showError('registerPasswordError', 'Password minimal 6 karakter');
                isValid = false;
            }
            
            if (password !== confirmPassword) {
                showError('registerConfirmPasswordError', 'Password tidak cocok');
                isValid = false;
            }
            
            if (isValid) {
                const newUser = {
                    id: Date.now().toString(),
                    name,
                    email,
                    password
                };
                
                users.push(newUser);
                alert('Pendaftaran berhasil! Silakan login.');
                
                registerForm.style.display = 'none';
                loginForm.style.display = 'block';
                this.reset();
            }
        });
        
        // Handle Login
        document.getElementById('loginFormElement').addEventListener('submit', function(e) {
            e.preventDefault();
            resetErrorMessages('login');
            
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            let isValid = true;
            
            if (!email) {
                showError('loginEmailError', 'Email harus diisi');
                isValid = false;
            }
            
            if (!password) {
                showError('loginPasswordError', 'Password harus diisi');
                isValid = false;
            }
            
            if (isValid) {
                const user = users.find(u => u.email === email && u.password === password);
                
                if (user) {
                    currentUser = user;
                    authContainer.style.display = 'none';
                    websiteContainer.style.display = 'block';
                    
                    // Update user avatar with initials
                    const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase();
                    userAvatar.textContent = initials;
                    
                    this.reset();
                } else {
                    showError('loginPasswordError', 'Email atau password salah');
                }
            }
        });
        
        // Handle Logout
        logoutBtn.addEventListener('click', () => {
            currentUser = null;
            websiteContainer.style.display = 'none';
            authContainer.style.display = 'block';
            loginForm.style.display = 'block';
            registerForm.style.display = 'none';
        });
        
        // Helper functions
        function resetErrorMessages(formType) {
            const errors = document.querySelectorAll(`#${formType}Form .error-message`);
            errors.forEach(error => {
                error.textContent = '';
                error.style.display = 'none';
            });
        }
        
        function showError(elementId, message) {
            const element = document.getElementById(elementId);
            element.textContent = message;
            element.style.display = 'block';
        }
        
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Initialize - Check if user is already logged in
        function init() {
            authContainer.style.display = 'block';
            websiteContainer.style.display = 'none';
        }
        
        init();
    </script>

    
</body>
</html>